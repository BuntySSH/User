using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
//T074 Jason
public class PlayerController : MonoBehaviour
{
    private Rigidbody2D rb;
    public float Speed;
    public Text CountTXT;
    private int count;
    public GameObject winTXT;
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        count = 0;
        setText();
        winTXT.SetActive(false);
    }
    void setText()
    {
        CountTXT.text = "Count: " + count.ToString();
        if (count >= 10)
        {
            winTXT.SetActive(true);
        }
    }

    void Update()
    {
        float Horizontal = Input.GetAxis("Horizontal");
        float Vertical = Input.GetAxis("Vertical");
        Vector2 Movement = new Vector2(Horizontal, Vertical);
        rb.AddForce(Movement*Speed);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("PickUps"))
        {
            collision.gameObject.SetActive(false);
            count++;
            setText();
        }
    }
}
