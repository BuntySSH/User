using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;
//T074 Jason
public class playerController : MonoBehaviour
{
    private Rigidbody rb;
    private int count;
    public TextMeshProUGUI countText;
    public GameObject winTextObject;
    public float speed;
    private float movementx, movementy;
    void Start()
    {
        rb = GetComponent<Rigidbody>(); 
        count= 0;
        setCountText();
        winTextObject.SetActive(false);
    }
    
    void OnMove(InputValue movementValue)
    {
        Vector2 movementVector = movementValue.Get<Vector2>();
        movementx = movementVector.x;
        movementy = movementVector.y;
    } 

    void setCountText()
    {
        countText.text = "Count: " + count.ToString();
        if (count >= 13) 
        {
            winTextObject.SetActive (true);
        }
    }

    void FixedUpdate()
    {
        Vector3 movement = new Vector3 (movementx, 0.0f,movementy);
        rb.AddForce(movement * speed);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("PickUp"))
        {
            other.gameObject.SetActive(false);
            count++;

            setCountText();
        }

    }

}
